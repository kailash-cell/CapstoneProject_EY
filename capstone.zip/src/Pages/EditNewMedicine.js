import axios from "axios";
import { useState,useEffect } from "react";
import {Link, useNavigate,useParams} from "react-router-dom";
export default function EditNewMedicine() {
    let navigate=useNavigate()

    // const{id}=useParams();

    const [savemedicine,setsavemedicine]= useState(
        {
            id:"",
            medicineName:"",
             brandName :"",
            price:"",
            quantity:""
        }
    );
    // const{id}=useParams();
    
    const{id,medicineName,brandName,price,quantity}=savemedicine;
   

    const onInputChange=(e) =>{
        setsavemedicine({...savemedicine,[e.target.id]:e.target.value});
    };

    useEffect(()=>{
        loadsavemedicine();
    },[]);

    const onSubmit= async (e)=>
    {
        e.preventDefault();
        await axios.post("http://localhost:8080/health/savemedicine",savemedicine)
        navigate("/manageproducts")
    };
    const loadsavemedicine= async ()=>
    {
        const result = await axios.post("http://localhost:8080/health/savemedicine");
        setsavemedicine(result.data);
    };

    return (
      <div class="container">
    <h2>EDITING MEDICINE </h2>
    

    <form class="form-horizontal" onSubmit={(e)=>onSubmit(e)}  >
      <div class="form-group">
        <label class="control-label col-sm-2" for="text">ID</label>
        <div class="col-sm-4">
          <input type="text" onChange={(e) => onInputChange(e)} class="form-control" id="id" placeholder="Enter id" name="id" value={id}/>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="pwd">MEDICINENAME</label>
        <div class="col-sm-4">          
          <input type="text" onChange={(e) => onInputChange(e)} class="form-control" id="medicineName" placeholder="Enter medicinename" name="medicineName" value={medicineName}/>
        </div>
      </div><div class="form-group">
        <label class="control-label col-sm-2" for="pwd">BRANDNENAME</label>
        <div class="col-sm-4">          
          <input type="text" onChange={(e) => onInputChange(e)} class="form-control" id="brandName" placeholder="Enter brandname" name="brandName" value={brandName}/>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="pwd">PRICE</label>
        <div class="col-sm-4">          
          <input type="text" onChange={(e) => onInputChange(e)} class="form-control" id="price" placeholder="Enter price" name="price" value={price}/>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="pwd">QUANTITY</label>
        <div class="col-sm-4">          
          <input type="text" onChange={(e)=>onInputChange(e)} class="form-control" id="quantity" placeholder="Enter quantity" name="quantity" value={quantity}/>
        </div>
      </div>
      
      <div class="form-group">        
        <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" class="btn btn-default bg-black text-white mt-3">Submit</button>
        </div>
      </div>
    </form>
  </div>
      
    );
  }
  