import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import signupform from "./signupform.jpg";
export default function Signup() {
  const [saveuser, setsaveuser] = useState({
    id:"",
    mobileNumber: "",
    firstName: "",
    lastName: "",
    Address: "",
    Email: "",
    password: "",
  });
  const { id,mobileNumber, firstName, lastName, Address, Email, password } = saveuser;

  const onInputChange = (e) => {
    setsaveuser({ ...saveuser, [e.target.id]: e.target.value });
  };

  let navigate = useNavigate();

  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:8080/users/saveuser",saveuser);
    navigate("/");
  };
  return (
    <div className="body">
    <div class="edit">
    <h2 class="signup">SIGNUP FORM</h2>
    

    <form class="form-horizontal" onSubmit={(e)=>onSubmit(e)}  >
    <div class="form-group">
        <label class="control-label col-sm-2" for="text">ID</label>
        <div class="col-sm-4">
          <input type="text" onChange={(e) => onInputChange(e)} class="form-control" id="id" placeholder="Enter id" name="id" value={id}/>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="firstName">First Name</label>
        <div class="col-sm-4">
          <input type="text" onChange={(e) => onInputChange(e)} class="form-control" id="firstName" placeholder="Enter firstname" name="firstName" value={firstName}/>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="lastName">Last Name</label>
        <div class="col-sm-4">          
          <input type="text" onChange={(e) => onInputChange(e)} class="form-control" id="lastName" placeholder="Enter lastname" name="lastName" value={lastName}/>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="mobileNumber">Mobile Number</label>
        <div class="col-sm-4">          
          <input type="text" onChange={(e) => onInputChange(e)} class="form-control" id="mobileNumber" placeholder="Enter number" name="mobileNumber" value={mobileNumber}/>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="Address">Address</label>
        <div class="col-sm-4">          
          <input type="text" onChange={(e) => onInputChange(e)} class="form-control" id="Address" placeholder="Enter address" name="Address" value={Address}/>
        </div>
      </div>
      
      <div class="form-group">
        <label class="control-label col-sm-2" for="Email">Email</label>
        <div class="col-sm-4">          
          <input type="email" onChange={(e) => onInputChange(e)} class="form-control" id="Email" placeholder="Enter email" name="Email" value={Email}/>
        </div>
      </div>
      
      <div class="form-group">
        <label class="control-label col-sm-2" for="password">Password</label>
        <div class="col-sm-4">          
          <input type="password" onChange={(e) => onInputChange(e)} class="form-control" id="password" placeholder="Enter password" name="password" value={password}/>
        </div>
      </div>
      
      <div class="form-group">        
        <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" class="btn btn-default bg-black text-white mt-3">Submit</button>
        </div>
      </div>
    </form>
  </div>
  </div>      

  );
}
