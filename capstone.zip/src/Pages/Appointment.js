import React from "react";
import { Link } from "react-router-dom";
import da1 from "./images/da1.jpg";
import da2 from "./images/da2.jpg";
import da3 from "./images/da3.jpg";
import da4 from "./images/da4.jpg";
import da5 from "./images/da5.jpg";
import da6 from "./images/da6.jpg";
import da7 from "./images/da7.jpg";
import da8 from "./images/da8.jpg";
import hc1 from "./images/hc1.jpg";
import hc2 from "./images/hc2.jpg";
import hc3 from "./images/hc3.jpg";
import hc4 from "./images/hc4.jpg";
import hc5 from "./images/hc5.jpg";
import hc6 from "./images/hc6.jpg";
import hc7 from "./images/hc7.png";
import hc8 from "./images/hc8.jpg";
import w1 from "./images/w1.jpg";
import w2 from "./images/w2.jpg";
import w3 from "./images/w3.jpg";
import w4 from "./images/w4.jpg";
import w5 from "./images/w5.jpg";
import w6 from "./images/w6.jpg";
import w7 from "./images/w7.jpg";
import sunlight from "./images/sunlight.jpg";
import stay from "./images/stayhydrated.jpg";
import healthy from "./images/Healthydiet.jpg";
import headache from "./images/headache.jpg";
import allergy from "./images/Allergy.jpg";
import highbp from "./images/highbp.jpg";
import cold from "./images/cold.png";
import insomnia from "./images/insomnia.jpg";
import diabetes from "./images/diabetes.jpg";
import vet from "./images/vetvisit.jpg";
import exercise from "./images/petexercise.jpg";
import training from "./images/pettraining.jpg";
import nutrition from "./images/petnutrition.jpg";
import grooming from "./images/petgrooming.jpg";
import safe from "./images/petssafe.jpg";
import aloe from "./images/aloevera.jpg";
import egg from "./images/EggMask.jpg";
import green from "./images/Green tea rinse.jpg";
import apple from "./images/AppleCiderVinegar.jpg";
import yogurt from "./images/Yogurt hair mask.jpg";
import hibsicus from "./images/Hibiscus hair mask.jpg";
import triphala from "./images/triphalaT.jpg";
import ghee from "./images/gheeTurmericMilk.jpg";
import fenu from "./images/fenugreekhairmask.webp";
import amla from "./images/amlahairoil.jpg";
import ginger from "./images/gingerlemontea.jpg";
import cumin from "./images/cuminCorianderT.jpg";
import cucum from "./images/cucumber1.jpg";
import rose from "./images/Rose water.jpg";
import milk from "./images/Milk.jpg";

import Test from "./images/TestFormimg.jpg";

export default function Appointment() {
  function addtocart() {
    alert("Product Added to cart");
  }
  return (
    <div>
      <nav id="navbar-example2" class="navbar navbar-light bg-light px-3">
        <a class="navbar-brand" href="#">
          Login Successfull
        </a>
        <Link to="/Viewproducts">ViewMedicines</Link>
        <ul class="nav nav-pills">
          <li class="nav-item">
            <a class="nav-link" href="#appointment">
              Appointment
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#healthlibrary">
              HealthCare Library
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#wellness">
              Wellness
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#healthconcern">
              Health Concern
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#bookonlinetest">
              Book Online Test
            </a>
          </li>
        </ul>
      </nav>
      <div
        data-bs-spy="scroll"
        data-bs-target="#navbar-example2"
        data-bs-offset="0"
        class="scrollspy-example"
        tabindex="0"
      />

      <div class="d-grid">
        <div>
          <div class="gallery" id="appointment">
            <a href="s.html">
              <img src={da1} alt="image" width="200" height="200" />
            </a>
            <p style={{ textAlign: "center" }}>General Medicine</p>
            <h6 style={{ textAlign: "center", color: "green" }}>24/7</h6>
            <h5 style={{ textAlign: "center", color: "black" }}>₹200</h5>
          </div>
          <div class="gallery">
            <a>
              <img src={da6} alt="image" width="200" height="200" />
            </a>
            <p style={{ textAlign: "center" }}>Gynecology</p>
            <h6 style={{ textAlign: "center", color: "green" }}>9am-9pm</h6>
            <h5 style={{ textAlign: "center", color: "black" }}>₹450</h5>
          </div>

          <div class="gallery">
            <a>
              <img src={da2} alt="image" width="200" height="200" />
            </a>
            <p style={{ textAlign: "center" }}>Cardiology</p>
            <h6 style={{ textAlign: "center", color: "green" }}>9am-1pm</h6>
            <h5 style={{ textAlign: "center", color: "black" }}>₹850</h5>
          </div>

          <div class="gallery">
            <a>
              <img src={da3} alt="image" width="200" height="200" />
            </a>
            <p style={{ textAlign: "center" }}>Pediatrics</p>
            <h6 style={{ textAlign: "center", color: "green" }}>24/7</h6>
            <h5 style={{ textAlign: "center", color: "black" }}>₹400</h5>
          </div>

          <div class="gallery">
            <a>
              <img src={da4} alt="image" width="200" height="200" />
            </a>
            <p style={{ textAlign: "center" }}>Hepatology</p>
            <h6 style={{ textAlign: "center", color: "green" }}>9am - 6pm</h6>
            <h5 style={{ textAlign: "center", color: "black" }}>₹567</h5>
          </div>
          <div class="gallery">
            <a>
              <img src={da5} alt="image" width="200" height="200" />
            </a>
            <p style={{ textAlign: "center" }}>Gynecology</p>
            <h6 style={{ textAlign: "center", color: "green" }}>24/7</h6>
            <h5 style={{ textAlign: "center", color: "black" }}>₹550</h5>
          </div>

          <div class="gallery">
            <a>
              <img src={da7} alt="image" width="200" height="200" />
            </a>
            <p style={{ textAlign: "center" }}>Dentist</p>
            <h6 style={{ textAlign: "center", color: "green" }}>10am5pm - </h6>
            <h5 style={{ textAlign: "center", color: "black" }}>₹600</h5>
          </div>
          <div class="gallery">
            <a>
              <img src={da8} alt="image" width="200" height="200" />
            </a>
            <p style={{ textAlign: "center" }}>ENT</p>
            <h6 style={{ textAlign: "center", color: "green" }}>8am - 8pm</h6>
            <h5 style={{ textAlign: "center", color: "black" }}>₹700</h5>
          </div>
        </div>

        <br></br>
        <br></br>
        {/* healthlibrary started */}
        <div>
          <div id="healthlibrary">
            <meta
              name="viewport"
              content="width=device-width, initial-scale=1"
            />
            <meta charset="utf-8" />
            <meta
              name="viewport"
              content="width=device-width, initial-scale=1, shrink-to-fit=no"
            />

            <link
              rel="stylesheet"
              href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
              integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
              crossorigin="anonymous"
            />

            <script
              src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
              integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
              crossorigin="anonymous"
            ></script>

            <script
              src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
              integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
              crossorigin="anonymous"
            ></script>
            <script
              src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
              integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
              crossorigin="anonymous"
            ></script>

            <h3>HEALTH LIBRARY</h3>
            <p>
              The National Library of Medicine is the world's largest biomedical
              library and a leader in research in computational health
              informatics. The National Library of Medicine is the world's
              largest biomedical library and a leader in research in
              computational health informatics. The National Library of Medicine
              is the world's largest biomedical library and a leader in research
              in computational health informatics. The National Library of
              Medicine is the world's largest biomedical library and a leader in
              research in computational health informatics.
            </p>
          </div>

          <h4 id="ailments">Ailments</h4>
          <div class="card-deck">
            <div class="card">
              <img class="card-img-top" src={headache} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Headache</h5>
                <p class="card-text">
                  Over-the-counter pain relievers such as acetaminophen
                  (Tylenol), ibuprofen (Advil, Motrin), and aspirin can help
                  relieve headache pain
                </p>
              </div>
            </div>

            <div class="card">
              <img class="card-img-top" src={highbp} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">High Blood Pressure</h5>
                <p class="card-text">
                  Medications such as ACE inhibitors, beta-blockers, and
                  diuretics can help lower blood pressure in people with
                  hypertension.
                </p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src={cold} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Cold</h5>
                <p class="card-text">
                  Over-the-counter cold and flu medications, such as
                  decongestants, antihistamines, and pain relievers, can help
                  alleviate symptoms such as congestion, runny nose, cough, and
                  fever.
                </p>
              </div>
            </div>
          </div>

          <div class="card-deck">
            <div class="card">
              <img class="card-img-top" src={insomnia} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Insomnia</h5>
                <p class="card-text">
                  Sleep aids such as diphenhydramine (Benadryl), zolpidem
                  (Ambien), and eszopiclone (Lunesta) can help improve sleep in
                  people with insomnia.
                </p>
              </div>
            </div>

            <div class="card">
              <img class="card-img-top" src={diabetes} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Diabetes</h5>
                <p class="card-text">
                  Medications such as metformin, sulfonylureas, and insulin can
                  help regulate blood sugar levels in people with diabetes.
                </p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src={allergy} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Allergy</h5>
                <p class="card-text">
                  Antihistamines such as loratadine (Claritin), cetirizine
                  (Zyrtec), and fexofenadine (Allegra) can help relieve symptoms
                  of allergies, such as sneezing, runny nose, and itchy eyes.
                </p>
              </div>
            </div>
          </div>

          <h4 id="beauty">Beauty and Care</h4>
          <div class="card-deck">
            <div class="card">
              <img class="card-img-top" src={sunlight} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Sunlight Protection</h5>
                <p class="card-text">
                  Protecting the skin from the sun's harmful UV rays is crucial
                  for preventing premature aging and reducing the risk of skin
                  cancer. Wearing a broad-spectrum sunscreen with an SPF of at
                  least 30 can help shield the skin from damage.
                </p>
              </div>
            </div>

            <div class="card">
              <img class="card-img-top" src={stay} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Stay Hydrated</h5>
                <p class="card-text">
                  Drinking plenty of water can help keep your skin hydrated and
                  improve its overall health.
                </p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src={healthy} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Healthy diet</h5>
                <p class="card-text">
                  Eating a diet rich in fruits, vegetables, and whole grains can
                  help keep your skin looking healthy and radiant.
                </p>
              </div>
            </div>
          </div>

          <h4 id="pet">Pet and Care</h4>
          <div class="card-deck">
            <div class="card">
              <img class="card-img-top" src={vet} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Vet visits</h5>
                <p class="card-text">
                  It's essential to take your pet to the veterinarian for
                  regular check-ups to ensure that they are healthy and to catch
                  any potential health issues early.
                </p>
              </div>
            </div>

            <div class="card">
              <img class="card-img-top" src={nutrition} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Proper Nutrition</h5>
                <p class="card-text">
                  Feeding your pet a balanced diet that meets their nutritional
                  needs is critical for their overall health and wellbeing.
                  Consult with your veterinarian for advice on the best food
                  options for your pet.
                </p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src={exercise} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Exercise</h5>
                <p class="card-text">
                  Regular exercise is important for your pet's physical and
                  mental health. Make sure your pet gets enough exercise and
                  playtime each day.
                </p>
              </div>
            </div>
          </div>

          <div class="card-deck">
            <div class="card">
              <img class="card-img-top" src={grooming} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Grooming</h5>
                <p class="card-text">
                  Proper grooming is necessary to maintain your pet's hygiene
                  and appearance. Depending on the type of pet you have, this
                  may include regular bathing, brushing, and nail trimming.
                </p>
              </div>
            </div>

            <div class="card">
              <img class="card-img-top" src={training} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Training</h5>
                <p class="card-text">
                  Proper training can help your pet learn good behavior and make
                  your relationship with them more enjoyable. Consider enrolling
                  your pet in obedience classes or working with a professional
                  trainer.
                </p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src={safe} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Safe environment</h5>
                <p class="card-text">
                  {" "}
                  Make sure your home and yard are safe for your pet. This may
                  include securing dangerous items, keeping toxic substances out
                  of reach, and providing a safe and comfortable living space.
                </p>
              </div>
            </div>
          </div>

          <h4 id="haircare">Haircare</h4>
          <div class="card-deck">
            <div class="card">
              <img class="card-img-top" src={aloe} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Aloe vera treatment</h5>
                <p class="card-text">
                  Aloe vera is a natural moisturizer and conditioner for hair.
                  Mix aloe vera gel with some coconut oil and apply it to your
                  hair, leave it on for 30 minutes, and then rinse it off with
                  water.
                </p>
              </div>
            </div>

            <div class="card">
              <img class="card-img-top" src={apple} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Apple cider vinegar rinse</h5>
                <p class="card-text">
                  Apple cider vinegar can help balance the pH level of your
                  scalp and remove product buildup. Mix apple cider vinegar with
                  water in equal parts and use it as a final rinse after
                  shampooing and conditioning your hair.
                </p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src={egg} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Egg mask</h5>
                <p class="card-text">
                  Eggs are rich in protein, which can strengthen your hair. Beat
                  one or two eggs and apply the mixture to your hair, leave it
                  on for 30 minutes, and then rinse it off with cool water.
                </p>
              </div>
            </div>
          </div>

          <div class="card-deck">
            <div class="card">
              <img class="card-img-top" src={yogurt} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Yogurt hair mask</h5>
                <p class="card-text">
                  Yogurt is a natural hair conditioner that can help soothe an
                  itchy scalp. Mix yogurt with some honey and apply it to your
                  hair, leave it on for 30 minutes, and then rinse it off with
                  water.
                </p>
              </div>
            </div>

            <div class="card">
              <img class="card-img-top" src={green} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Green tea rinse</h5>
                <p class="card-text">
                  Green tea is rich in antioxidants that can help promote hair
                  growth and reduce hair loss. Brew some green tea and use it as
                  a final rinse after shampooing and conditioning your hair.
                </p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src={hibsicus} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Hibiscus hair mask</h5>
                <p class="card-text">
                  Hibiscus flowers are rich in vitamins and antioxidants that
                  can help promote hair growth and reduce hair loss. Crush some
                  hibiscus flowers and mix them with coconut oil, apply the
                  mixture to your hair, leave it on for 30 minutes, and then
                  rinse it off with water.
                </p>
              </div>
            </div>
          </div>

          <h4 id="ayur">Ayurvedic Home Remedies</h4>
          <div class="card-deck">
            <div class="card">
              <img class="card-img-top" src={triphala} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Triphala Tea</h5>
                <p class="card-text">
                  Boil 1 teaspoon of Triphala powder in 2 cups of water for 5-10
                  minutes. Strain and drink the tea in the morning on an empty
                  stomach. Triphala tea can help improve digestion, boost
                  immunity, and cleanse the colon.
                </p>
              </div>
            </div>

            <div class="card">
              <img class="card-img-top" src={amla} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Amla Hair Oil</h5>
                <p class="card-text">
                  Mix 1 cup of coconut oil with 1/4 cup of amla powder. Heat the
                  mixture on low heat for 10-15 minutes, stirring occasionally.
                  Strain the oil and use it to massage your scalp and hair. Amla
                  hair oil can help promote hair growth, reduce hair fall, and
                  improve scalp health.
                </p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src={ghee} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Ghee and Turmeric Golden Milk</h5>
                <p class="card-text">
                  Heat 1 cup of milk in a pan and add 1 teaspoon of ghee and 1/2
                  teaspoon of turmeric powder. Stir well and drink this milk
                  before bedtime. This golden milk can help improve digestion,
                  promote better sleep, and boost immunity.
                </p>
              </div>
            </div>
          </div>

          <div class="card-deck">
            <div class="card">
              <img class="card-img-top" src={ginger} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Ginger and Lemon Tea</h5>
                <p class="card-text">
                  Boil 1 cup of water and add 1 teaspoon of grated ginger and
                  the juice of half a lemon. Let it simmer for a few minutes and
                  strain the tea. Ginger and lemon tea can help improve
                  digestion, reduce inflammation, and boost immunity.
                </p>
              </div>
            </div>

            <div class="card">
              <img class="card-img-top" src={fenu} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Fenugreek Hair Mask</h5>
                <p class="card-text">
                  Soak 1/4 cup of fenugreek seeds in water overnight. In the
                  morning, grind the soaked seeds to make a paste. Apply the
                  paste to your scalp and hair and leave it on for 30 minutes
                  before rinsing off. Fenugreek hair mask can help promote hair
                  growth, reduce hair fall, and improve scalp health
                </p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src={cumin} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Cumin and Coriander Digestive Tea</h5>
                <p class="card-text">
                  {" "}
                  Boil 1 teaspoon of cumin seeds and 1 teaspoon of coriander
                  seeds in 2 cups of water for 5-10 minutes. Strain and drink
                  this tea after meals to help improve digestion, reduce
                  bloating, and prevent indigestion.
                </p>
              </div>
            </div>
          </div>

          <h4 id="eyecare">Eye Care</h4>
          <div class="card-deck">
            <div class="card">
              <img class="card-img-top" src={cucum} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Cucumber</h5>
                <p class="card-text">
                  Cut a cucumber into slices and place them over your closed
                  eyes for 10-15 minutes. This can help reduce puffiness and
                  soothe tired eyes.To lighten dark circle,grate a cucumber and
                  extract the juice. Dip a cotton ball in the juice and apply it
                  to the area around your eyes. Leave it on for 10-15 minutes
                  and then rinse off with cool water. The natural bleaching
                  agents in cucumber can help lighten dark circles around your
                  eyes. To moisturize the skin around the eye blend a cucumber
                  into a paste and mix it with a tablespoon of aloe vera gel.
                  Apply the mixture to the skin around your eyes and leave it on
                  for 10-15 minutes before rinsing off with cool water. This can
                  help moisturize and nourish the delicate skin around your
                  eyes. To soothe eye irritation place cucumber slices in the
                  refrigerator to cool. Once chilled, place the slices over your
                  closed eyes for 10-15 minutes. The anti-inflammatory
                  properties of cucumber can help soothe eye irritation and
                  redness.
                </p>
              </div>
            </div>

            <div class="card">
              <img class="card-img-top" src={rose} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Rose water</h5>
                <p class="card-text">
                  Soak a cotton ball in rose water and gently apply it to your
                  closed eyes for a few minutes. This can help soothe and
                  refresh tired eyes. To soothe tired eyes,soak cotton balls in
                  rose water and place them over your closed eyes for 10-15
                  minutes. The coolness and gentle fragrance of the rose water
                  can help soothe tired eyes and reduce puffiness. To reduce eye
                  redness, mix equal parts of rose water and cold water in a
                  bowl. Dip a cotton ball in the mixture and apply it to your
                  closed eyes for a few minutes. The anti-inflammatory
                  properties of rose water can help reduce eye redness and
                  irritation.
                </p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src={milk} alt="Card image cap" />
              <div class="card-body">
                <h5 class="card-title">Milk</h5>
                <p class="card-text">
                  Dip a cotton ball in cold milk and apply it around your eyes.
                  Leave it on for 10-15 minutes and then rinse off with cool
                  water. This can help reduce puffiness and soothe tired eyes.
                  To reduce dark circles, Mix equal parts of milk and cold water
                  in a bowl. Soak two cotton balls in the mixture and place them
                  over your closed eyes for 10-15 minutes. This can help reduce
                  the appearance of dark circles around your eyes. To Relieve
                  eye irritation: Mix equal parts of milk and honey in a bowl.
                  Dip a cotton ball in the mixture and apply it to your closed
                  eyes for a few minutes. The anti-inflammatory properties of
                  honey and the cooling effect of milk
                </p>
              </div>
            </div>
          </div>

          {/* health library ended */}
          {/* health concern started */}
          <div id="healthconcern">
            <div>
              <h3>HEALTH CONCERNS</h3>
              <div class="gallery" id="healthconcern">
                <a href="https://www.lung.org/lung-health-diseases/wellness/protecting-your-lungs">
                  <img src={hc1} alt="image" width="200" height="200" />
                </a>
                <p style={{ textAlign: "center" }}>Lung Care</p>
              </div>
              <div class="gallery" id="healthconcern">
                <a href="https://www.nia.nih.gov/health/maintaining-healthy-weight">
                  <img src={hc2} alt="image" width="200" height="200" />
                </a>
                <p style={{ textAlign: "center" }}>Weight Care</p>
              </div>
              <div class="gallery" id="healthconcern">
                <a href="https://www.sciencedirect.com/topics/medicine-and-dentistry/womens-care">
                  <img src={hc3} alt="image" width="200" height="200" />
                </a>
                <p style={{ textAlign: "center" }}>Womens Care</p>
              </div>
              <div class="gallery" id="healthconcern">
                <a href="https://my.clevelandclinic.org/health/symptoms/17752-joint-pain">
                  <img src={hc4} alt="image" width="200" height="200" />
                </a>
                <p style={{ textAlign: "center" }}>Bone and Joint Pain Care</p>
              </div>
              <div class="gallery" id="healthconcern">
                <a href="https://medlineplus.gov/ency/patientinstructions/000466.htm">
                  <img src={hc5} alt="image" width="200" height="200" />
                </a>
                <p style={{ textAlign: "center" }}>Cold and Fever</p>
              </div>
              <div class="gallery" id="healthconcern">
                <a href="https://www.webmd.com/heart/heart-health-tips">
                  <img src={hc6} alt="image" width="200" height="200" />
                </a>
                <p style={{ textAlign: "center" }}>Heart Care</p>
              </div>
              <div class="gallery" id="healthconcern">
                <a href="https://www.enthealth.org/whats-an-ent/">
                  <img src={hc7} alt="image" width="200" height="200" />
                </a>
                <p style={{ textAlign: "center" }}>ENT</p>
              </div>
              <div class="gallery" id="healthconcern">
                <a href="https://medlineplus.gov/ency/patientinstructions/000466.htmhttps://shcc.ufl.edu/services/primary-care/health-care-info-online/patient-education-cough-or-cold-what-to-take/">
                  <img src={hc8} alt="image" width="200" height="200" />
                </a>
                <p style={{ textAlign: "center" }}>Cold and Fever</p>
              </div>
            </div>
          </div>
        </div>
        {/* health concern ended */}
        {/* wellness started */}
        <div>
          <div id="wellness">
            <div>
              <h3>Wellness</h3>
              <div class="gallery" id="wellness">
                <img src={w1} alt="image" width="200" height="200" />
                <p style={{ textAlign: "center" }}>
                  Dettol Antiseptic Liquid 550 ml
                </p>
                <h6 style={{ textAlign: "center", color: "green" }}>
                  Mkt: Reckitt Benckiser India Ltd{" "}
                </h6>
                <h5 style={{ textAlign: "center", color: "black" }}>
                  Best price* Rs. 105.00
                </h5>
                <Link to="/BookSuccess">
                  <button class="book" onClick={addtocart}>
                    Add To Cart
                  </button>
                </Link>
              </div>
              <div class="gallery" id="wellness">
                <img src={w2} alt="image" width="200" height="200" />

                <p style={{ textAlign: "center" }}>
                  Newnik Pulse Oximeter with Audio Visual Alarm
                </p>
                <h6 style={{ textAlign: "center", color: "green" }}>
                  Mkt: Newnik Lifecare Pvt Ltd
                </h6>
                <h5 style={{ textAlign: "center", color: "black" }}>
                  Best price* Rs. 1250.00
                </h5>
                <Link to="/BookSuccess">
                  <button class="book" onClick={addtocart}>
                  Add To Cart
                  </button>
                </Link>
              </div>
              <div class="gallery" id="wellness">
                <img src={w3} alt="image" width="200" height="200" />

                <p style={{ textAlign: "center" }}>
                  Patanjali Divya Swasari Coronil Kit
                </p>
                <h6 style={{ textAlign: "center", color: "green" }}>
                  Mkt: Patanjali Ayurved Ltd
                </h6>
                <h5 style={{ textAlign: "center", color: "black" }}>
                  Best price* Rs. 200.00
                </h5>
                <Link to="/BookSuccess">
                  <button class="book" onClick={addtocart}>
                  Add To Cart
                  </button>
                </Link>
              </div>
              <div class="gallery" id="wellness">
                <img src={w4} alt="image" width="200" height="200" />

                <p style={{ textAlign: "center" }}>
                  Hansaplast Silverhealing Antibacterial Bandage
                </p>
                <h6 style={{ textAlign: "center", color: "green" }}>
                  Mkt: Essity Operations Goa Ltd
                </h6>
                <h5 style={{ textAlign: "center", color: "black" }}>
                  Best price* Rs. 450.00
                </h5>
                <Link to="/BookSuccess">
                  <button class="book" onClick={addtocart}>
                  Add To Cart
                  </button>
                </Link>
              </div>
              <div class="gallery" id="wellness">
                <img src={w5} alt="image" width="200" height="200" />

                <p style={{ textAlign: "center" }}>
                  Wilson Belladonna Plaster Perforated 10's
                </p>
                <h6 style={{ textAlign: "center", color: "green" }}>
                  Mkt: Wilson Tapes Pvt Ltd
                </h6>
                <h5 style={{ textAlign: "center", color: "black" }}>
                  Best price* Rs. 100.00
                </h5>
                <Link to="/BookSuccess">
                  <button class="book" onClick={addtocart}>
                  Add To Cart
                  </button>
                </Link>
              </div>
              <div class="gallery" id="wellness">
                <img src={w6} alt="image" width="200" height="200" />

                <p style={{ textAlign: "center" }}>
                  Netmeds 3 Ply Face Mask With Nose Pin 100's
                </p>
                <h6 style={{ textAlign: "center", color: "green" }}>
                  Mkt: Reliance Reatil Limited
                </h6>
                <h5 style={{ textAlign: "center", color: "black" }}>
                  Best price* Rs. 95.00
                </h5>
                <Link to="/BookSuccess">
                  <button class="book" onClick={addtocart}>
                  Add To Cart
                  </button>
                </Link>
              </div>
              <div class="gallery" id="wellness">
                <img src={w7} alt="image" width="200" height="200" />

                <p style={{ textAlign: "center" }}>
                  Hansaplast Lion Plaster Pain Relief Patch - Perforated
                </p>
                <h6 style={{ textAlign: "center", color: "green" }}>
                  Mkt: Essity Operations Goa Ltd
                </h6>
                <h5 style={{ textAlign: "center", color: "black" }}>
                  Best price* Rs. 135.00
                </h5>
                <Link to="/BookSuccess">
                  <button class="book" onClick={addtocart}>
                  Add To Cart
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
        <br></br>
        <br></br>
        {/* wellness ended */}
        {/* Book Online HealthCare Test Started*/}
        <div id="bookonlinetest">
          <div>
            <h3 style={{ textAlign: "center" }}>
              Book Online Health Care Test
            </h3>
            <div className="form">
              <section class="h-100 ">
                <div class="container py-5 h-100">
                  <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col">
                      <div class="card card-registration my-4">
                        <div class="row g-0">
                          <div class="col-xl-3  ">
                            <img
                              src={Test}
                              alt="Sample photo"
                              class="img-fluid w-100 h-100 "
                            />
                          </div>
                          <div class="col-xl-6">
                            <div class="card-body p-md-5 text-black">
                              <h3 class="mb-5 text-uppercase">
                                Registration form
                              </h3>

                              <div class="row"></div>
                              <div class="form-outline mb-4">
                                <input
                                  type="text"
                                  id="name"
                                  class="form-control form-control-lg"
                                  required
                                />
                                <label class="form-label" for="name">
                                  Name
                                </label>
                              </div>
                              <div class="form-outline mb-4">
                                <input
                                  type="tel"
                                  id="tel"
                                  class="form-control form-control-lg"
                                  required
                                />
                                <label class="form-label" for="tel">
                                  Mobile Number
                                </label>
                              </div>

                              <div class="form-outline mb-4">
                                <input
                                  type="text"
                                  id="add"
                                  class="form-control form-control-lg"
                                  required
                                />
                                <label class="form-label" for="add">
                                  Address
                                </label>
                              </div>

                              <div class="d-md-flex justify-content-start align-items-center mb-4 py-2">
                                <h6 class="mb-0 me-4">Gender: </h6>

                                <div class="form-check form-check-inline mb-0 me-4">
                                  <input
                                    class="form-check-input"
                                    type="radio"
                                    name="inlineRadioOptions"
                                    id="femaleGender"
                                    value="option1"
                                    required
                                  />
                                  <label
                                    class="form-check-label"
                                    for="femaleGender"
                                  >
                                    Female
                                  </label>
                                </div>

                                <div class="form-check form-check-inline mb-0 me-4">
                                  <input
                                    class="form-check-input"
                                    type="radio"
                                    name="inlineRadioOptions"
                                    id="maleGender"
                                    value="option2"
                                    required
                                  />
                                  <label
                                    class="form-check-label"
                                    for="maleGender"
                                  >
                                    Male
                                  </label>
                                </div>

                                <div class="form-check form-check-inline mb-0">
                                  <input
                                    class="form-check-input"
                                    type="radio"
                                    name="inlineRadioOptions"
                                    id="otherGender"
                                    value="option3"
                                    required
                                  />
                                  <label
                                    class="form-check-label"
                                    for="otherGender"
                                  >
                                    Other
                                  </label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="col-md-6 mb-4" required>
                                  <select class="select">
                                    <option value="1">State</option>
                                    <option value="2">Telangana</option>
                                    <option value="3">Chennai</option>
                                    <option value="4">Andra Pradesh</option>
                                  </select>
                                </div>
                                <div class="col-md-6 mb-4" required>
                                  <select class="select">
                                    <option value="1">City</option>
                                    <option value="2">Hyderabad</option>
                                    <option value="3">Guindy</option>
                                    <option value="4">Warangal</option>
                                  </select>
                                </div>
                              </div>
                              <div class="d-flex justify-content-end pt-3">
                                <Link to="/BookSuccess">
                                  {" "}
                                  <button
                                    type="button"
                                    class="btn btn-warning btn-lg ms-2"
                                  >
                                    Book Now
                                  </button>
                                </Link>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
      {/* Book Online HealthCare Test ended*/}

      {/* write any code above this */}
    </div>
  );
}
