import { Link } from "react-router-dom";
export default function Login() {
  function addtocart(){
    alert("User Login Success")
  }

  return (
    <div >
    <div class="login">
  <h2 id="h2">Login form</h2>
  <form class="form-horizontal" action="/Appointment">
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-4">
        <input type="email" class="form-control" id="email" placeholder="email" name="email" required/>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Password:</label>
      <div class="col-sm-4">          
        <input type="password" class="form-control" id="pwd" placeholder="password" name="pwd" required/>
      </div>
    </div><br></br>
   
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10 m-2">
        <button type="submit" class="btn btn-default bg-white text-black mt-3" onClick={addtocart}>Submit</button>
        <Link to="/Signup"><button type="button" class="btn text-white mt-3 new-user">New User</button></Link>
      </div>
    </div>
  </form>
</div>
    </div>
  );
}
