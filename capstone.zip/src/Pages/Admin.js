export default function Admin() {
    return (
      
      <div className="admin">
        <div class="container t-one">
        <h2 id="t">Admin form</h2>
        <form class="form-horizontal" action="/Manageproducts" >
          <div class="form-group">
            <label class="control-label col-sm-2" for="email">Email</label>
            <div class="col-sm-4">
              <input type="email" class="form-control-one" id="email" placeholder="email" name="email" required/>
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">Password</label>
            <div class="col-sm-4">          
              <input type="password" class="form-control-one" id="pwd" placeholder=" password" name="pwd" required/>
            </div>
          </div>
          {/* <div class="form-group">        
            <div class="col-sm-offset-2 col-sm-10">
              <div class="checkbox">
              <input type="checkbox" name="remember" required/>
                <label> Remember me</label>

              </div>
            </div>
          </div> */}
          <div class="form-group">        
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" class="btn btn-default bg-black text-white mt-3">Submit</button>
            </div>
          </div>
        </form>
      </div>
          
      </div>   
      
    );
  }
  