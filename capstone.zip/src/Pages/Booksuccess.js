import gif from "./images/success.gif";
export default function BookSuccess(){
    return(
        <div class="appointment">
            <br></br>
            <br></br>
            <br></br>
            <h2>PRODUCT ADDED SUCCESSFULLY</h2>
            <img src={gif} alt="image" width="400" height="400"/>
        </div>
    )
}