import aboutimg from "./images/aboutimg.jpg";
export default function About(){
    return(
        <div>
        <div class="c">
        <h2>About Us</h2>
        </div>
        <div>
            <p>
            <h3>
               <a href="https://www.who.int/india/about-us">WHO</a>
            </h3>
            World Health Organization (WHO) is the United Nations’ specialized agency for Health. 
            It is an inter-governmental organization and works in collaboration with its member states usually through the Ministries of Health. 
            The World Health Organization is responsible for providing leadership on global health matters, shaping the health research agenda, setting norms and standards, articulating evidence-based policy options, providing technical support to countries and monitoring and assessing health trends.
            India became a party to the WHO Constitution on 12 January 1948. The first session of the WHO Regional Committee for South-East Asia was held on 4-5 October 1948 in the office of the Indian Minister of Health. It was inaugurated by Pandit Jawaharlal Nehru, Prime Minister of India and was addressed by the WHO Director-General, Dr Brock Chisholm. India is a Member State of the WHO South East Asia Region.
            </p>
            <img src={aboutimg} alt="Image" width={800}></img>
        </div>
    <div>
        <footer>
       <p>REFERENCES<br></br>
       <a href="https://www.who.int/india/about-us">HEALTHCARE</a></p>
        </footer>
    </div>
        </div>
    )
}