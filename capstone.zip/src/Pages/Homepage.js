import medicare from "./medicarebackground.png"

export default function Homepage(){
    return(
    <div class="home">

   <div class="dropdown">
   <a class="btn btn-secondary dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
    CATEGORY
   </a>

  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="https://www.bing.com/images/search?q=Antitussive+Drugs&form=RESTAB&first=1" target="_blank">Antipyretics</a></li>
    <li><a class="dropdown-item" href="https://www.bing.com/images/search?q=Analgesics&form=HDRSC4&first=1" target="_blank">Analgesics</a></li>
    <li><a class="dropdown-item" href="https://www.bing.com/images/search?q=Amoxicillin+Antibiotics&form=RESTAB&first=1" target="_blank">Antibiotics</a></li>
  </ul>
</div>
<div class="medi">
  <img src={medicare}  width={750}/>
</div>

 </div>

    )
}