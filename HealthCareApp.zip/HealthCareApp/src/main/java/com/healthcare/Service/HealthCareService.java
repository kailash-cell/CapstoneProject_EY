package com.healthcare.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthcare.Model.HealthCare;
import com.healthcare.Repository.HealthCareRepository;

@Service
public class HealthCareService {
	
	@Autowired
	private HealthCareRepository careRepository;
	
	public List<HealthCare> getAll(){
		return careRepository.findAll();
	}
	public HealthCare save(HealthCare obj1) {
		
		return careRepository.save(obj1);
		
	}
	public void deletebyId(Long id) {
		// TODO Auto-generated method stub
		careRepository.deleteById(id);	
	}
	public void saveorUpdate(HealthCare medicine) {
		// TODO Auto-generated method stub
		careRepository.save(medicine);
		
	}	

}
